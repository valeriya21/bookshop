const payForm = [
   {
      id: 1,
      name: "Visa",
      icon: "fab fa-cc-visa"
   },
   {
      id: 2,
      name: "Mastercard",
      icon: "fab fa-cc-mastercard"
   },
   {
      id: 3,
      name: "Paypal",
      icon: "fab fa-cc-paypal"
   },
   {
      id: 4,
      name: "Bank #1",
      icon: "fas fa-landmark"
   },
   {
      id: 5,
      name: "Bank #2",
      icon: "fas fa-landmark"
   },
   {
      id: 6,
      name: "Bank #3 ",
      icon: "fas fa-landmark"
   },
   {
      id: 7,
      name: "Bank #4 ",
      icon: "fas fa-landmark"
   },
   {
      id: 8,
      name: "Bank #5 ",
      icon: "fas fa-landmark"
   },
   {
      id: 9,
      name: "Bank #6",
      icon: "fas fa-landmark"
   },
   {
      id: 10,
      name: "Bank #7 ",
      icon: "fas fa-landmark"
   },
   {
      id: 11,
      name: "Bank #8 ",
      icon: "fas fa-landmark"
   },
   {
      id: 12,
      name: "Bank #9 ",
      icon: "fas fa-landmark"
   }
];

export default payForm;
