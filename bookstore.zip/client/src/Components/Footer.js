import React from "react";
const Footer = () => {
   return <footer>React book shop</footer>;
};
export default Footer;
