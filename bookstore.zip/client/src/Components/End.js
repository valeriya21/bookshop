import React from "react";
const End = () => {
   return (
      <div className="end">
         <h1>Thanks for watching</h1>
      </div>
   );
};

export default End;
